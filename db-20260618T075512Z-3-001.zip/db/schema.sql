-- COLSI DATABASE SCHEMA (PostgreSQL)
-- Derived from "How data is gathered for COLSI.txt"

-- 1. RAW DATA LAYER (Ingestion)
CREATE TABLE raw_food_prices (
    id SERIAL PRIMARY KEY,
    item_name TEXT,
    price NUMERIC,
    unit TEXT,
    source TEXT,
    location TEXT,
    collected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE raw_transport_data (
    id SERIAL PRIMARY KEY,
    type TEXT, -- fuel, bus, ride
    price NUMERIC,
    source TEXT,
    location TEXT,
    collected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE raw_energy_data (
    id SERIAL PRIMARY KEY,
    type TEXT, -- electricity, gas
    price NUMERIC,
    outage_minutes INT DEFAULT 0,
    source TEXT,
    location TEXT,
    collected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE raw_housing_data (
    id SERIAL PRIMARY KEY,
    rent NUMERIC,
    area TEXT,
    bedrooms INT,
    source TEXT,
    collected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. PROCESSED FACTOR LAYER (Analytics)
CREATE TABLE factor_scores (
    id SERIAL PRIMARY KEY,
    factor TEXT, -- food, transport, energy, housing
    score NUMERIC,
    baseline NUMERIC,
    change_percent NUMERIC,
    calculated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. FINAL COLSI CORE LAYER (Master Index)
CREATE TABLE colsi_index (
    id SERIAL PRIMARY KEY,
    food_score NUMERIC,
    transport_score NUMERIC,
    energy_score NUMERIC,
    housing_score NUMERIC,
    colsi_value NUMERIC,
    stress_level TEXT, -- LOW, MODERATE, HIGH, CRITICAL
    calculated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 4. HUMAN INTELLIGENCE LAYER (Crowd Source)
CREATE TABLE user_reports (
    id SERIAL PRIMARY KEY,
    factor TEXT,
    value NUMERIC,
    sentiment TEXT, -- AGGRAVATED, NEUTRAL, COMFORTABLE
    location TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
