# COLSI Machine Learning Layer: Data Storage Documentation

This documentation provides the official schema and mock datasets for the COLSI Machine Learning layer. These files are designed to be ingested by the `mlPredictor.ts` engine for training and validation.

## 1. Datasets Overview

We have provided two primary datasets (tabs/files) for the judges:

### [A] Training Dataset (`colsi_ml_training_data.csv`)
*   **Purpose**: Used for training the time-series forecasting model.
*   **Update Frequency**: Daily Batch.
*   **Columns**:
    *   `Date`: Observation timestamp (YYYY-MM-DD).
    *   `Food_Price_Index`: Weighted average of food costs.
    *   `Energy_Tariff_Index`: Normalized energy cost factor.
    *   `Transport_Fare_Index`: Average transport volatility score.
    *   `Housing_Rent_Index`: Median smoothed rent values.
    *   `Sentiment_Signal`: Aggregated user sentiment (0 = Panic, 50 = Stable, 100 = Optimistic).
    *   `COLSI_Stress_Index`: The final calculated index (Target Variable).
    *   `Anomaly_Detected`: Binary flag (1 = Spike detected, 0 = Normal).

### [B] Raw Ingestion Log (`colsi_raw_ingestion_log.csv`)
*   **Purpose**: Demonstrates the source-to-feature pipeline.
*   **Update Frequency**: Real-time / Hourly.
*   **Columns**:
    *   `Timestamp`: Unix epoch.
    *   `Source`: Origin of data (e.g., GroceryAPI, FuelBoard).
    *   `Category`: Food, Energy, Transport, or Housing.
    *   `Raw_Value`: Unprocessed numeric value.
    *   `Location`: Geographic filter (e.g., Dhaka, Chattogram).

## 2. ML Data Schema (JSON Representative)

For developers using the API directly, the ML layer expects the following feature vector:

```json
{
  "currentScore": number,  // Current COLSI index
  "ma3": number,           // 3-day Moving Average
  "ma7": number,           // 7-day Moving Average
  "momentum": number,      // Daily delta
  "volatility": number,    // Standard deviation of scores
  "sentimentSignal": number // Crowd-sourced input
}
```

## 3. Storage Architecture

Data should be stored in a columnar format (Parquet for production, CSV for prototyping) to ensure high-speed retrieval of historical sequences for LSTM/XGBoost models.
