import { BrowserRouter } from 'react-router-dom';
import { PlatformProvider } from './context/PlatformContext';
import StandardHub from './versions/Standard/StandardHub';

function App() {
  return (
    <PlatformProvider>
      <BrowserRouter>
        <div className="min-h-screen w-full bg-background overflow-hidden relative">
          <StandardHub />
        </div>
      </BrowserRouter>
    </PlatformProvider>
  );
}

export default App;

