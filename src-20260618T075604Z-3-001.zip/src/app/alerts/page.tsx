"use client";

import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  AlertCircle, 
  Clock, 
  ChevronRight, 
  Zap, 
  Bell,
  Activity,
  ShieldAlert
} from 'lucide-react';
import { getStressLevelColor } from '../../services/colsiCore';





const AlertsPage = () => {
  const alerts = [
    { id: '1', type: 'CRITICAL', protocol: 'ALPHA_RED', message: 'Massive surge in essential food prices detected in the Northern Sector.', timestamp: Date.now() - 1000 * 60 * 5, node: 'NX-022', region: 'North' },
    { id: '2', type: 'HIGH', protocol: 'BETA_ORANGE', message: 'Regional energy consumption nearing projected quarterly capacity in Dhaka.', timestamp: Date.now() - 1000 * 60 * 30, node: 'NX-014', region: 'Dhaka' },
    { id: '3', type: 'MODERATE', protocol: 'SIGMA_YELLOW', message: 'Transport cost volatility intersecting with historical highs in Chittagong.', timestamp: Date.now() - 1000 * 60 * 120, node: 'NX-401', region: 'Chittagong' }
  ];

  return (
    <div className="space-y-10">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-text-primary uppercase tracking-tight">Tactical Alert Stream</h1>
          <p className="text-text-secondary mt-1">Real-time anomalous cost-vector detection and synchronization.</p>
        </div>
        
        <div className="flex items-center gap-4">
           <div className="px-4 py-2 bg-surface-elevated rounded-xl border border-border flex items-center gap-3">
             <Bell size={16} className="text-primary animate-pulse" />
             <span className="text-[10px] font-bold text-text-primary uppercase tracking-widest">3 Active Vectors detected</span>
           </div>
           <button className="btn-primary h-11 px-6">Resolve Protocol</button>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <StatsCard label="Critical Threats" value="01" icon={<ShieldAlert size={20} />} status="CRITICAL" />
        <StatsCard label="Processing Delay" value="12ms" icon={<Zap size={20} />} />
        <StatsCard label="System Integrity" value="99.9" icon={<Activity size={20} />} />
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between px-2">
           <h3 className="text-xs font-bold text-text-primary uppercase tracking-[0.2em]">Synchronized Stream Monitor</h3>
           <div className="text-[10px] font-bold text-primary uppercase tracking-widest cursor-pointer hover:underline flex items-center gap-2">
              Filter by Severity <ChevronRight size={12} />
           </div>
        </div>

        <div className="space-y-3">
          <AnimatePresence>
            {alerts.map((alert, idx) => {
              const statusColor = getStressLevelColor(alert.type as "CRITICAL" | "HIGH" | "MODERATE" | "STABLE");
              return (
                <motion.div 
                  key={alert.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  className="colsi-card flex items-center gap-8 p-6 group border border-transparent hover:border-border hover:bg-surface-elevated transition-all"
                >
                   <div 
                    className="w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 border"
                    style={{ backgroundColor: `${statusColor}10`, borderColor: `${statusColor}30`, color: statusColor }}
                   >
                     <AlertCircle size={24} />
                   </div>

                   <div className="flex-1">
                      <div className="flex items-center gap-3 mb-1.5">
                         <span className="text-[10px] font-black uppercase tracking-widest" style={{ color: statusColor }}>
                           {alert.type}_VECTOR_STATUS
                         </span>
                         <span className="text-[9px] text-text-secondary opacity-40 font-mono tracking-tighter uppercase">Protocol: {alert.protocol}</span>
                         <div className="h-1 w-1 rounded-full bg-border" />
                         <span className="text-[9px] text-text-secondary opacity-40 font-mono tracking-tighter uppercase">Node: {alert.node}</span>
                      </div>
                      <p className="text-lg font-bold text-text-primary tracking-tight leading-snug">{alert.message}</p>
                   </div>

                   <div className="flex items-center gap-6">
                      <div className="flex items-center gap-2 px-4 py-1.5 bg-surface rounded-lg border border-border">
                         <Clock size={12} className="text-text-secondary" />
                         <span className="text-[10px] font-bold text-text-secondary uppercase tracking-widest">{formatTime(alert.timestamp)}</span>
                      </div>
                      <button className="text-primary hover:bg-primary/10 p-3 rounded-full transition-all border border-transparent hover:border-primary/20">
                         <ChevronRight size={20} />
                      </button>
                   </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

interface StatsCardProps {
  label: string;
  value: string;
  icon: React.ReactNode;
  status?: string;
}


const StatsCard = ({ label, value, icon, status }: StatsCardProps) => {
  const color = status ? getStressLevelColor(status) : 'inherit';
  return (
    <div className="colsi-card p-8 flex flex-col justify-between h-44 group border border-transparent hover:border-border">
      <div className="flex justify-between items-start">
        <div 
          className="w-12 h-12 rounded-xl flex items-center justify-center border transition-all"
          style={{ backgroundColor: status ? `${color}15` : '#262626', borderColor: status ? `${color}40` : '#404040', color: status ? color : '#a3a3a3' }}
        >
           {icon}
        </div>
        <p className="text-[10px] font-bold text-text-secondary uppercase tracking-[0.2em] mt-2">{label}</p>
      </div>
      <div className="mt-4 flex items-baseline gap-2">
         <span className="text-5xl font-black tracking-tighter text-text-primary group-hover:text-primary transition-colors">{value}</span>
         {status && <span className="text-[10px] font-bold uppercase tracking-widest mb-1" style={{ color }}>{status}</span>}
      </div>
    </div>
  );
};

const formatTime = (ts: number) => {
  const diff = Date.now() - ts;
  const mins = Math.floor(diff / (1000 * 60));
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  return `${hours}h ago`;
};

export default AlertsPage;
