"use client";

import { motion } from 'framer-motion';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Radar, 
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis,
  AreaChart,
  Area
} from 'recharts';
import { TrendingUp, Activity, PieChart, BarChart3, Info } from 'lucide-react';
import { getStressLevelColor } from '../../services/colsiCore';

const AnalyticsPage = () => {
  // Simulated time-series data for the 4 COLSI factors
  const timelineData = [
    { name: '00:00', energy: 45, food: 38, transport: 56, housing: 42 },
    { name: '04:00', energy: 52, food: 41, transport: 58, housing: 42 },
    { name: '08:00', energy: 68, food: 55, transport: 72, housing: 43 },
    { name: '12:00', energy: 84, food: 72, transport: 85, housing: 45 },
    { name: '16:00', energy: 78, food: 88, transport: 76, housing: 46 },
    { name: '20:00', energy: 92, food: 82, transport: 68, housing: 48 },
    { name: '24:00', energy: 88, food: 78, transport: 74, housing: 50 },
  ];

  const factorIntensity = [
    { subject: 'Energy', A: 92, fullMark: 100 },
    { subject: 'Food', A: 88, fullMark: 100 },
    { subject: 'Transport', A: 74, fullMark: 100 },
    { subject: 'Housing', A: 82, fullMark: 100 },
    { subject: 'Inflation', A: 65, fullMark: 100 },
    { subject: 'Burden', A: 78, fullMark: 100 },
  ];

  const regionalComparison = [
    { name: 'Dhaka', score: 84 },
    { name: 'Chatto', score: 78 },
    { name: 'Sylhet', score: 72 },
    { name: 'Khulna', score: 74 },
    { name: 'Rajshahi', score: 45 },
    { name: 'Barishal', score: 22 },
  ];

  return (
    <div className="space-y-10">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-text-primary uppercase tracking-tight">Factor Analytics Hub</h1>
          <p className="text-text-secondary mt-1">Multi-dimensional telemetry processing and historical trend mapping.</p>
        </div>
        <div className="flex gap-4">
           <div className="px-4 py-2 bg-surface-elevated border border-border rounded-lg flex items-center gap-3">
             <Activity size={16} className="text-primary" />
             <span className="text-[10px] font-bold text-text-primary uppercase tracking-widest">Active Stream: LF_ANALYTICS_01</span>
           </div>
        </div>
      </header>

      {/* Main Analysis Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Trend Analysis */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="colsi-card p-8 min-h-[450px] flex flex-col"
        >
          <div className="flex justify-between items-start mb-10">
            <div>
              <p className="text-[10px] font-bold text-text-secondary uppercase tracking-[0.2em] mb-1">Temporal Propagation</p>
              <h3 className="text-xl font-bold text-text-primary">24h Pressure Timeline</h3>
            </div>
            <TrendingUp size={20} className="text-primary" />
          </div>
          <div className="flex-1 w-full min-h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={timelineData}>
                <defs>
                  <linearGradient id="colorEnergy" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={getStressLevelColor('CRITICAL')} stopOpacity={0.3}/>
                    <stop offset="95%" stopColor={getStressLevelColor('CRITICAL')} stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#262626" vertical={false} />
                <XAxis 
                  dataKey="name" 
                  stroke="#525252" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false}
                  dy={10}
                />
                <YAxis 
                  stroke="#525252" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false} 
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#171717', border: '1px solid #262626', borderRadius: '8px' }}
                  itemStyle={{ fontSize: '10px', fontWeight: 'bold', textTransform: 'uppercase' }}
                />
                <Area type="monotone" dataKey="energy" stroke={getStressLevelColor('CRITICAL')} fillOpacity={1} fill="url(#colorEnergy)" />
                <Area type="monotone" dataKey="food" stroke="#3b82f6" fillOpacity={0} />
                <Area type="monotone" dataKey="transport" stroke="#a855f7" fillOpacity={0} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Intensity Radar */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="colsi-card p-8 min-h-[450px] flex flex-col"
        >
          <div className="flex justify-between items-start mb-10">
            <div>
              <p className="text-[10px] font-bold text-text-secondary uppercase tracking-[0.2em] mb-1">Impact Distribution</p>
              <h3 className="text-xl font-bold text-text-primary">Factor Intensity Mapping</h3>
            </div>
            <PieChart size={20} className="text-primary" />
          </div>
          <div className="flex-1 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height={350}>
              <RadarChart cx="50%" cy="50%" outerRadius="80%" data={factorIntensity}>
                <PolarGrid stroke="#262626" />
                <PolarAngleAxis dataKey="subject" tick={{ fill: '#a3a3a3', fontSize: 10, fontWeight: 'bold' }} />
                <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
                <Radar
                  name="Intensity"
                  dataKey="A"
                  stroke={getStressLevelColor('CRITICAL')}
                  fill={getStressLevelColor('CRITICAL')}
                  fillOpacity={0.4}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
      </div>

      {/* Regional Comparison */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="colsi-card p-8"
      >
        <div className="flex justify-between items-start mb-10">
          <div>
            <p className="text-[10px] font-bold text-text-secondary uppercase tracking-[0.2em] mb-1">Spatial Comparison</p>
            <h3 className="text-xl font-bold text-text-primary">Regional Stress Cross-Analysis</h3>
          </div>
          <BarChart3 size={20} className="text-primary" />
        </div>
        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={regionalComparison}>
              <CartesianGrid strokeDasharray="3 3" stroke="#262626" vertical={false} />
              <XAxis dataKey="name" stroke="#525252" fontSize={10} tickLine={false} axisLine={false} dy={10} />
              <YAxis stroke="#525252" fontSize={10} tickLine={false} axisLine={false} />
              <Tooltip 
                cursor={{ fill: 'rgba(255,255,255,0.05)' }}
                contentStyle={{ backgroundColor: '#171717', border: '1px solid #262626', borderRadius: '8px' }}
                itemStyle={{ fontSize: '10px', fontWeight: 'bold', textTransform: 'uppercase' }}
              />
              <Bar 
                dataKey="score" 
                fill={getStressLevelColor('CRITICAL')} 
                radius={[4, 4, 0, 0]}
                barSize={40}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      <div className="p-6 bg-surface-elevated border border-border rounded-xl flex items-center justify-center gap-6">
        <Info size={16} className="text-primary shrink-0" />
        <p className="text-[10px] font-bold text-text-secondary uppercase tracking-[0.15em] text-center">
          Intelligence Warning: Cumulative housing burden in <span className="text-text-primary">Dhaka Metropolitan</span> projected to intersect <span className="text-primary">CRITICAL</span> threshold within 12 cycles.
        </p>
      </div>
    </div>
  );
};

export default AnalyticsPage;
