"use client";

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Lightbulb, 
  Zap, 
  AlertTriangle, 
  ShieldAlert,
  Play,
  ShoppingBag,
  Home,
  Car,
  Target,
  Activity
} from 'lucide-react';
import { getStressLevelColor } from '../../services/colsiCore';
import type { Insight } from '../../types/economic';

interface InsightLocal extends Omit<Insight, 'category' | 'severity'> {
  id: string;
  category: string;
  severity: string;
  confidence: number;
  horizon: string;
  action: string;
}

interface TelemetryProps {
  label: string;
  value: string | number;
  color?: string;
  highlight?: boolean;
}

interface CategoryIconProps {
  category: string;
  size: number;
  className?: string;
}

interface SeverityIconProps {
  severity: string;
}

const InsightsPage = () => {
  const [activeCategory, setActiveCategory] = useState('all');

  const insights: InsightLocal[] = [
    { 
      id: '1', 
      category: 'food', 
      title: 'Staple Flux Anomaly', 
      severity: 'critical', 
      confidence: 94.2, 
      horizon: '48h',
      description: 'AI detected significant divergence in rice and lentil price vectors across eastern hubs. Predictive models suggest a 12% surge if logistics bottlenecks persist.', 
      action: 'Deploy rebalancing',
      timestamp: new Date().toISOString()
    },
    { 
      id: '2', 
      category: 'energy', 
      title: 'Grid Load Overpressure', 
      severity: 'warning', 
      confidence: 81.5, 
      horizon: '12h',
      description: 'Thermal power generation efficiency dipping due to input cost volatility. Real-time load-shedding risks localized to industrial sectors.', 
      action: 'Initiate pivot',
      timestamp: new Date().toISOString()
    },
    { 
      id: '3', 
      category: 'transport', 
      title: 'Logistics Chain Tension', 
      severity: 'moderate', 
      confidence: 76.8, 
      horizon: '72h',
      description: 'Freight costs correlating with seasonal fuel adjustment frequencies. Optimized routing suggested for northern supply chains.', 
      action: 'Review protocol',
      timestamp: new Date().toISOString()
    },
    { 
      id: '4', 
      category: 'housing', 
      title: 'Urban Density Inflation', 
      severity: 'high', 
      confidence: 89.1, 
      horizon: '30d',
      description: 'Utility cost layering in metropolitan zones exceeds predicted baseline. Rent-to-income ratios nearing critical 40% threshold.', 
      action: 'Optimize grid',
      timestamp: new Date().toISOString()
    }
  ];

  const filteredInsights = activeCategory === 'all' ? insights : insights.filter(i => i.category === activeCategory);

  return (
    <div className="space-y-10">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-text-primary uppercase tracking-tight">Intelligence Matrix</h1>
          <p className="text-text-secondary mt-1">High-frequency predictive patterns derived from Generative COLSI Models.</p>
        </div>
        
        <div className="flex gap-2 bg-surface-elevated p-1 rounded-xl border border-border">
          {['all', 'food', 'energy', 'transport', 'housing'].map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all ${
                activeCategory === cat ? 'bg-primary text-white shadow-lg' : 'text-text-secondary hover:text-text-primary hover:bg-surface'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </header>

      <div className="space-y-6">
        <AnimatePresence mode='popLayout'>
          {filteredInsights.map((insight, idx) => (
            <motion.div 
              key={insight.id}
              layout
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.05 }}
              className="colsi-card group !max-w-none flex flex-col md:flex-row gap-10 p-8 border border-transparent hover:border-primary/20"
            >
              <div className="w-full md:w-56 h-56 rounded-2xl shrink-0 flex items-center justify-center relative overflow-hidden bg-surface-elevated border border-border group-hover:bg-primary/5 transition-all">
                <div className="absolute top-0 left-0 p-3 flex items-center gap-2 opacity-50">
                  <Activity size={12} className="text-primary animate-pulse" />
                  <span className="text-[9px] font-bold text-text-secondary uppercase">Live Stream</span>
                </div>
                <SeverityIcon severity={insight.severity} />
                <div className="absolute bottom-4 left-4 text-[10px] font-bold text-text-secondary flex items-center gap-2">
                   <CategoryIcon category={insight.category} size={14} className="text-primary" />
                   <span className="uppercase tracking-widest">{insight.category}</span>
                </div>
              </div>

              <div className="flex-1 flex flex-col justify-center">
                <div className="flex items-center gap-4 mb-4">
                   <div className="px-3 py-1 rounded-full bg-primary/10 text-primary text-[9px] font-bold tracking-widest uppercase">Generative_Alpha_v3</div>
                   <div className="h-1 w-1 rounded-full bg-border" />
                   <span className="text-[9px] text-text-secondary font-mono tracking-tighter uppercase">Processor: NODE_0x{insight.id}FF</span>
                </div>
                <h3 className="text-3xl font-bold text-text-primary tracking-tight">{insight.title}</h3>
                <p className="text-text-secondary text-base mt-4 leading-relaxed max-w-2xl font-medium">
                  {insight.description}
                </p>

                <div className="flex gap-12 mt-8 pt-8 border-t border-border">
                   <Telemetry label="Model Confidence" value={`${insight.confidence}%`} highlight={insight.confidence > 90} />
                   <Telemetry label="Predictive Horizon" value={insight.horizon} />
                   <Telemetry label="Load Vector" value={insight.severity.toUpperCase()} color={getStressLevelColor(insight.severity.toUpperCase() === 'CRITICAL' ? 'CRITICAL' : 'HIGH')} />
                </div>
              </div>

              <div className="flex md:flex-col justify-center gap-4 min-w-[200px]">
                <button className="btn-primary w-full h-12 flex items-center justify-center gap-3">
                  <Play size={16} fill="white" />
                  Apply Sync
                </button>
                <button className="btn-secondary w-full h-12">Track Vector</button>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
};

const Telemetry = ({ label, value, color, highlight }: TelemetryProps) => (
  <div>
     <p className="text-[10px] font-bold text-text-secondary uppercase tracking-widest mb-1">{label}</p>
     <p className={`text-lg font-bold ${highlight ? 'text-primary' : color || 'text-text-primary'}`}>{value}</p>
  </div>
);

const CategoryIcon = ({ category, size, className }: CategoryIconProps) => {
  switch (category) {
    case 'energy': return <Zap size={size} className={className}/>;
    case 'food': return <ShoppingBag size={size} className={className}/>;
    case 'transport': return <Car size={size} className={className}/>;
    case 'housing': return <Home size={size} className={className}/>;
    default: return <Lightbulb size={size} className={className}/>;
  }
};

const SeverityIcon = ({ severity }: SeverityIconProps) => {
  switch (severity) {
    case 'critical': return <ShieldAlert size={48} className="text-primary relative z-10 animate-pulse" />;
    case 'warning': return <AlertTriangle size={48} className="text-amber-500 relative z-10" />;
    default: return <Target size={48} className="text-text-secondary relative z-10" />;
  }
};

export default InsightsPage;
