"use client";

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Zap,
  ShoppingBasket,
  Car,
  Home,
  ChevronRight,
  TrendingDown,
  TrendingUp,
  Activity,
  Cpu,
  Globe,
  Database,
  ArrowUpRight,
  ArrowDownRight,
  FileText,
  Download,
  X,
  Target,
  RefreshCw,
  BarChart3
} from 'lucide-react';
import { getStressLevelColor } from '../services/colsiCore';
import { usePlatform } from '../hooks/usePlatform';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

const Dashboard = () => {
  const { searchQuery } = usePlatform();
  const [activeModal, setActiveModal] = useState<string | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isTracked, setIsTracked] = useState(false);
  const [timeframe, setTimeframe] = useState<'day' | 'week' | 'month' | 'year'>('month');
  const [factorTimeframes, setFactorTimeframes] = useState<Record<string, 'day' | 'week' | 'month' | 'year'>>({
    energy: 'month',
    food: 'month',
    transport: 'month',
    housing: 'month'
  });

  const getTimeframeVariation = (tf: 'day' | 'week' | 'month' | 'year') => {
    switch (tf) {
      case 'day': return 0.98;
      case 'week': return 0.99;
      case 'month': return 1.0;
      case 'year': return 1.02;
      default: return 1.0;
    }
  };

  const timeframeVariation = getTimeframeVariation(timeframe);
  const baseIndex = 72.4;
  const overallIndex = Math.min(100, Math.max(1, parseFloat((baseIndex * timeframeVariation).toFixed(1))));
  const numericIndex = overallIndex;
  
  const stressLevel = numericIndex > 85 ? "CRITICAL" : numericIndex > 60 ? "HIGH" : "STABLE";
  const stressColor = getStressLevelColor(stressLevel as "CRITICAL" | "HIGH" | "MODERATE" | "STABLE");

  const factorData = [
    { 
      id: 'energy', 
      title: "Energy", 
      baseValue: 84.2,
      trend: "up", 
      status: "CRITICAL", 
      icon: <Zap size={18} />, 
      description: "Power grid volatility and price fluctuations driving operational costs." 
    },
    { 
      id: 'food', 
      title: "Food", 
      baseValue: 68.5,
      trend: "up", 
      status: "HIGH", 
      icon: <ShoppingBasket size={18} />, 
      description: "Core commodity index reflecting regional supply chain dynamics." 
    },
    { 
      id: 'transport', 
      title: "Transport", 
      baseValue: 42.1,
      trend: "down", 
      status: "MODERATE", 
      icon: <Car size={18} />, 
      description: "Logistics optimization mitigating immediate sector inflationary pressure." 
    },
    { 
      id: 'housing', 
      title: "Housing", 
      baseValue: 12.4,
      trend: "stable", 
      status: "STABLE", 
      icon: <Home size={18} />, 
      description: "Residential trends remaining within established market parameters." 
    },
  ];

  const processedFactors = factorData.map(f => {
    const tf = factorTimeframes[f.id] || timeframe;
    const variation = getTimeframeVariation(tf);
    const value = Math.min(100, Math.max(1, parseFloat((f.baseValue * variation).toFixed(1))));
    return { ...f, value, timeframe: tf };
  });

  const filteredFactors = processedFactors.filter(f => 
    f.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
    f.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const resourceVectors = [
    { name: "LNG Input", value: `$${(14.2 * timeframeVariation).toFixed(1)}`, delta: "+2.4%", trend: "up" },
    { name: "Diesel Avg", value: `৳${(108.5 * (timeframe === 'year' ? 1.05 : 1)).toFixed(1)}`, delta: "+1.1%", trend: "up" },
    { name: "Paddy Index", value: (2450 * (timeframe === 'year' ? 0.95 : 1)).toLocaleString(), delta: "-0.8%", trend: "down" },
    { name: "Grid Load", value: `${(14.2 * timeframeVariation).toFixed(1)}GW`, delta: "+4.2%", trend: "up" },
  ];
;

  const handleDownloadPDF = async () => {
    const element = document.getElementById('analytics-report-target');
    if (!element) return;
    
    setIsSyncing(true);
    try {
      const canvas = await html2canvas(element, { 
        scale: 1, // Baseline scale for absolute stability
        useCORS: true,
        allowTaint: true,
        scrollX: 0,
        scrollY: 0,
        windowWidth: 1200, // Fixed width for consistent layout capture
        logging: false,
        onclone: (clonedDoc) => {
          const modal = clonedDoc.querySelector('.fixed.inset-0');
          if (modal) modal.remove();
          
          const target = clonedDoc.getElementById('analytics-report-target');
          if (target) {
            target.style.background = '#020617';
            target.style.padding = '40px';
          }
        }
      });
      
      const imgData = canvas.toDataURL('image/png', 0.8);
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgProps = pdf.getImageProperties(imgData);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
      
      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save(`COLSI_STRATEGIC_REPORT_${new Date().getTime()}.pdf`);
    } catch (error) {
      console.error('PDF Generation Failed:', error);
      alert('System Synchronization Error: PDF engine failed to synthesize report. Attempting fallback protocol...');
    } finally {
      setIsSyncing(false);
    }
  };

  const handleApplySync = () => {
    setIsSyncing(true);
    setTimeout(() => setIsSyncing(false), 2000);
  };

  return (
    <div id="dashboard-container" className="space-y-10 pb-20 relative">
      <AnimatePresence>
        {activeModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 sm:p-24 backdrop-blur-xl bg-background/40">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="w-full max-w-4xl bg-surface-elevated border border-border rounded-3xl p-10 shadow-2xl relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 p-6">
                <button onClick={() => setActiveModal(null)} className="p-2 hover:bg-surface rounded-full transition-colors">
                  <X size={24} className="text-text-secondary" />
                </button>
              </div>

              {activeModal === 'sectors' ? (
                <div className="space-y-8">
                  <div className="flex items-center gap-4">
                    <BarChart3 className="text-primary w-8 h-8" />
                    <div>
                      <h2 className="text-2xl font-bold text-text-primary uppercase tracking-tight">Sector Performance Analysis</h2>
                      <p className="text-text-secondary text-sm">Detailed analysis of current economic indicators and sector performance.</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {processedFactors.map(f => (
                      <div key={f.id} className="p-6 rounded-2xl bg-background/50 border border-border">
                        <div className="flex justify-between items-center mb-4">
                           <span className="text-xs font-black text-text-primary uppercase tracking-widest">{f.title} Sector</span>
                           <span className="text-xl font-bold text-primary">{f.value}</span>
                        </div>
                        <p className="text-xs text-text-secondary leading-relaxed">{f.description}</p>
                        <div className="mt-4 flex items-center justify-between text-[10px] font-bold text-text-secondary uppercase tracking-widest mb-1">
                            <span>Statistical Scale</span>
                            <span className="text-primary">{f.timeframe}</span>
                         </div>
                         <div className="mt-1 h-1 w-full bg-border rounded-full overflow-hidden">
                           <div className="h-full bg-primary" style={{ width: `${Math.min(100, f.value)}%` }} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : activeModal === 'stream' ? (
                <div className="space-y-8">
                  <div className="flex items-center gap-4">
                    <Activity className="text-primary w-8 h-8" />
                    <div>
                      <h2 className="text-2xl font-bold text-text-primary uppercase tracking-tight">Stream Analytics Flow</h2>
                      <p className="text-text-secondary text-sm">Real-time data synchronization and validation stream.</p>
                    </div>
                  </div>
                  <div className="bg-surface p-6 rounded-2xl border border-border font-mono text-[10px] space-y-2 max-h-[400px] overflow-y-auto">
                     <p className="text-primary">[CONNECTED] HUB_DHAKA_CENTRAL: INGESTING_ENERGY_DATA...</p>
                     <p className="text-text-secondary"># ANALYZING_LNG_DATA: $14.2 / MCF [VALIDATED]</p>
                     <p className="text-text-secondary"># SECTOR_ANALYSIS: FOOD_MARKET_NORTH: +2.1% DELTA</p>
                     <p className="text-primary">[SYNC] CROSS_REFERENCE: TRANSPORT_FUEL_INDEX_STABLE</p>
                     <p className="text-text-secondary"># HOUSING_VARIANCE: NEGLIGIBLE [0.12%]</p>
                     <p className="text-primary animate-pulse">[!] ANOMALY_DETECTED: ENERGY_HUB_CHG: +5.4% LIMIT_REACHED</p>
                     <p className="text-text-secondary"># RECALCULATING_INDEX: NEW_VAL: 72.4 [SYSTEM_READY]</p>
                  </div>
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-2xl font-bold text-text-primary uppercase tracking-tight">{activeModal} Performance Insights</h2>
                      <p className="text-text-secondary text-sm">Detailed performance metrics and historical variance for the {activeModal} sector.</p>
                    </div>
                    <div className="px-4 py-2 bg-primary/10 border border-primary/20 rounded-xl">
                      <span className="text-[10px] font-black text-primary uppercase tracking-widest">Protocol: 0x{Math.random().toString(16).slice(2,6).toUpperCase()}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {[
                      { label: "Stability Index", value: "98.4%", status: "OPTIMAL" },
                      { label: "Cost Drift", value: "+1.24%", status: "UPSTREAM" },
                      { label: "Data Coverage", value: "Locked", status: "SYNCED" }
                    ].map((stat, i) => (
                      <div key={i} className="p-4 bg-background/50 border border-border rounded-2xl">
                        <p className="text-[9px] font-bold text-text-secondary uppercase tracking-widest mb-1">{stat.label}</p>
                        <p className="text-lg font-bold text-text-primary">{stat.value}</p>
                        <p className="text-[8px] font-black text-primary mt-1 uppercase tracking-tighter">{stat.status}</p>
                      </div>
                    ))}
                  </div>

                  <div className="p-8 bg-surface rounded-3xl border border-border overflow-hidden relative group">
                    <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-transparent" />
                    <div className="relative z-10 flex flex-col md:flex-row gap-8 items-center">
                      <div className="flex-1 space-y-4">
                        <h3 className="text-sm font-black text-text-primary uppercase tracking-widest">Sector Performance Heatmap</h3>
                        <p className="text-xs text-text-secondary leading-relaxed">
                          The {activeModal} sector is currently experiencing {activeModal === 'Energy' ? 'high LNG input volatility' : activeModal === 'Food' ? 'challenges in grain distribution' : activeModal === 'Transport' ? 'fuel price stabilization benefits' : 'standard inflationary variance'}. Core data hubs are successfully mitigating {activeModal === 'Energy' ? 'load shedding risks' : 'market fluctuations'}.
                        </p>
                        <div className="flex gap-4">
                          <button className="px-6 py-2 bg-primary text-background text-[9px] font-black uppercase rounded-lg">Run Deep Analysis</button>
                          <button className="px-6 py-2 border border-border text-text-secondary text-[9px] font-black uppercase rounded-lg">Export CSV</button>
                        </div>
                      </div>
                      <div className="w-full md:w-48 h-32 bg-background/40 border border-border rounded-xl flex items-center justify-center">
                         <div className="flex items-end gap-1 px-4 h-16">
                            {[40, 70, 45, 90, 65, 80, 50].map((h, i) => (
                              <motion.div 
                                key={i}
                                initial={{ height: 0 }}
                                animate={{ height: `${h}%` }}
                                transition={{ delay: i * 0.1, duration: 1 }}
                                className="w-2 bg-primary/40 rounded-t-full" 
                              />
                            ))}
                         </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>


      <div id="analytics-report-target" className="space-y-10">
        <div className="flex flex-col lg:flex-row gap-8">
        <div className="flex-1 flex flex-col gap-8">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-[10px] font-bold text-primary uppercase tracking-[0.3em] mb-1">Strategic Action Plan 2026</p>
              <h1 className="text-text-primary uppercase tracking-tight text-4xl font-extrabold">Executive Dashboard</h1>
              <p className="text-text-secondary mt-1 max-w-xl text-sm leading-relaxed">Multimodal economic analytics cross-referenced with regional growth metrics.</p>
            </div>
            
            <div className="flex items-center gap-1 p-1 bg-surface-elevated border border-border rounded-xl">
               {(['day', 'week', 'month', 'year'] as const).map((t) => (
                 <button
                   key={t}
                   onClick={() => setTimeframe(t)}
                   className={`px-4 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all ${timeframe === t ? 'bg-primary text-background shadow-lg shadow-primary/20' : 'text-text-secondary hover:text-text-primary'}`}
                 >
                   {t}
                 </button>
               ))}
            </div>
          </div>

          <div className="colsi-card !max-w-none p-12 flex flex-col items-center justify-center relative overflow-hidden group border-primary/20 shadow-2xl shadow-primary/5">
             <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-primary/10 via-transparent to-transparent opacity-50" />
             <div className="relative z-10 text-center">
                <p className="text-[10px] font-black text-text-secondary uppercase tracking-[0.5em] mb-6 opacity-60">Aggregate Cost Index</p>
                <div className="flex flex-col items-center">
                   <span className="text-[160px] font-black tracking-tighter text-text-primary leading-none bg-gradient-to-b from-text-primary via-text-primary to-surface bg-clip-text text-transparent">
                    {overallIndex}
                   </span>
                   <div className="flex items-center gap-6 mt-4">
                      <div 
                        className="px-8 py-2.5 rounded-full border-2 text-[11px] font-black uppercase tracking-[0.2em] shadow-lg"
                        style={{ color: stressColor, borderColor: `${stressColor}40`, backgroundColor: `${stressColor}10` }}
                      >
                        {stressLevel} THRESHOLD
                      </div>
                      <div className="flex items-center gap-2">
                         <div className={`w-2 h-2 rounded-full bg-primary ${isSyncing ? 'animate-ping' : ''}`} />
                         <span className="text-text-secondary text-[10px] font-mono uppercase tracking-widest">Real-time Data Core</span>
                      </div>
                   </div>
                </div>
             </div>
             
             <div className="absolute top-0 left-10 w-[1px] h-20 bg-gradient-to-b from-primary/50 to-transparent" />
             <div className="absolute top-0 right-10 w-[1px] h-20 bg-gradient-to-b from-primary/50 to-transparent" />
          </div>

        </div>

        <div className="w-full lg:w-80 space-y-6">
           <div className="colsi-card p-6 !max-w-none flex flex-col justify-between h-[180px] bg-surface-elevated">
              <div className="flex justify-between items-start">
                 <div>
                    <p className="text-[9px] font-black text-text-secondary uppercase tracking-widest mb-1">System Utilization</p>
                    <h4 className="text-xl font-bold text-text-primary">94.2%</h4>
                 </div>
                 <Cpu size={18} className="text-primary" />
              </div>
              <div className="space-y-4">
                <button onClick={handleApplySync} className="w-full py-2 bg-primary/10 border border-primary/30 rounded flex items-center justify-center gap-2 group transition-all hover:bg-primary/20">
                   <RefreshCw size={12} className={`${isSyncing ? 'animate-spin' : ''} text-primary`} />
                   <span className="text-[9px] font-black text-primary uppercase tracking-widest">Synchronize Data</span>
                </button>
              </div>
           </div>

           <div className="colsi-card p-6 !max-w-none flex flex-col justify-between h-[180px] border-primary/20">
              <div className="flex justify-between items-start">
                 <div>
                    <p className="text-[9px] font-black text-text-secondary uppercase tracking-widest mb-1">Impact Variance</p>
                    <div className="flex items-center gap-2">
                       <h4 className="text-2xl font-bold text-primary">+4.1</h4>
                       <ArrowUpRight size={16} className="text-primary" />
                    </div>
                 </div>
                 <Activity size={18} className="text-primary animate-pulse" />
              </div>
              <button onClick={() => setIsTracked(!isTracked)} className={`w-full py-2 border rounded flex items-center justify-center gap-2 transition-all ${isTracked ? 'bg-primary text-background border-primary' : 'border-border text-text-secondary hover:border-primary/50'}`}>
                 <Target size={12} />
                 <span className="text-[9px] font-black uppercase tracking-widest">{isTracked ? 'Metric Analyzed' : 'Analyze Metric'}</span>
              </button>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {filteredFactors.map((factor) => {
          const statusColor = getStressLevelColor(factor.status);
          return (
            <button 
              key={factor.title} 
              onClick={() => setActiveModal(factor.title)}
              className="colsi-card text-left flex flex-col justify-between p-6 group transition-all duration-500 hover:scale-[1.02] hover:border-primary/40"
            >
              <div className="flex justify-between items-start">
                <div 
                  className="p-2.5 rounded-lg border transition-all duration-500"
                  style={{ backgroundColor: `${statusColor}10`, borderColor: `${statusColor}30`, color: statusColor }}
                >
                  {factor.icon}
                </div>
                <div className="flex items-center gap-1.5 px-2 py-1 bg-surface-elevated border border-border rounded-lg">
                  {factor.trend === 'up' ? <TrendingUp size={12} className="text-primary" /> : factor.trend === 'down' ? <TrendingDown size={12} className="text-text-secondary" /> : <Activity size={12} className="text-text-secondary" />}
                  <span className="text-[9px] font-black text-text-primary uppercase tracking-tighter">{factor.status}</span>
                </div>
              </div>
              
              <div className="mt-8 flex justify-between items-end">
                <div>
                  <p className="text-[9px] font-bold text-text-secondary uppercase tracking-[0.2em] opacity-60">{factor.title} Index</p>
                  <div className="flex items-baseline gap-2 mt-1">
                    <span className="text-3xl font-black text-text-primary tracking-tighter">{factor.value}</span>
                    <span className="text-[9px] text-text-secondary font-mono uppercase opacity-30">{factor.timeframe}</span>
                  </div>
                </div>
                <div className="flex gap-1 mb-1">
                  {(['day', 'week', 'month', 'year'] as const).map((tf) => (
                    <button
                      key={tf}
                      onClick={(e) => {
                        e.stopPropagation();
                        setFactorTimeframes(prev => ({ ...prev, [factor.id]: tf }));
                      }}
                      className={`w-6 h-4 rounded text-[7px] font-bold uppercase transition-all ${factor.timeframe === tf ? 'bg-primary text-background' : 'bg-surface hover:bg-surface-elevated text-text-secondary'}`}
                    >
                      {tf.charAt(0)}
                    </button>
                  ))}
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-border flex items-center justify-between opacity-50 group-hover:opacity-100 transition-opacity">
                <span className="text-[8px] font-black text-text-secondary uppercase tracking-[0.2em]">Open Details</span>
                <ChevronRight size={12} className="text-text-secondary group-hover:text-primary" />
              </div>
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="colsi-card p-8 lg:col-span-1 space-y-8 flex flex-col justify-between">
           <div>
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-xs font-black uppercase tracking-[0.2em] text-text-primary">Analytics Feed</h3>
                <Database size={16} className="text-text-secondary" />
              </div>
              <div className="space-y-6">
                {resourceVectors.map((res) => (
                  <div key={res.name} className="flex items-center justify-between group cursor-pointer hover:bg-surface-elevated/50 p-2 -m-2 rounded-lg transition-all">
                    <div>
                      <p className="text-[10px] font-bold text-text-secondary uppercase mb-0.5">{res.name}</p>
                      <p className="text-sm font-bold text-text-primary">{res.value}</p>
                    </div>
                    <div className="text-right">
                       <div className={`flex items-center gap-1 ${res.trend === 'up' ? 'text-primary' : 'text-text-secondary'}`}>
                          {res.trend === 'up' ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
                          <span className="text-[10px] font-black">{res.delta}</span>
                       </div>
                    </div>
                  </div>
                ))}
              </div>
           </div>
           <button onClick={() => setActiveModal('stream')} className="w-full h-10 bg-surface-elevated border border-border rounded-lg text-[10px] font-black uppercase tracking-widest hover:border-primary transition-all">
              Expand Stream Details
           </button>
        </div>

        <div className="colsi-card p-8 lg:col-span-1 flex flex-col justify-between border-primary/20 group hover:shadow-2xl hover:shadow-primary/10 transition-all">
           <div>
              <div className="flex items-center justify-between mb-6">
                 <h3 className="text-xs font-black uppercase tracking-[0.2em] text-text-primary">Strategic Report</h3>
                 <FileText size={16} className="text-primary" />
              </div>
              <p className="text-[10px] text-text-secondary leading-relaxed uppercase tracking-wide">
                 Comprehensive synthesis of current economic performance factors, predictive cost forecasting, and strategic recommendations.
              </p>
           </div>
           <button 
             onClick={handleDownloadPDF}
             className="w-full h-14 bg-primary text-background rounded-xl text-xs font-black uppercase tracking-[0.2em] flex items-center justify-center gap-3 hover:scale-[1.02] active:scale-95 transition-all shadow-lg shadow-primary/20"
           >
              {isSyncing ? <RefreshCw className="animate-spin" size={16} /> : <Download size={16} />}
              <span className="leading-none">Generate Report PDF</span>
           </button>
        </div>

        <div className="colsi-card p-8 lg:col-span-1 flex flex-col justify-between border-border overflow-hidden relative group">
           <div className="space-y-4">
              <h3 className="text-xs font-black uppercase tracking-[0.2em] text-text-primary mb-2">Sector Breakdown</h3>
              <div className="space-y-3">
                 {[
                   { name: "Energy Grid", val: "Critical", color: "#ef4444" },
                   { name: "Food Logistics", val: "High", color: "#f97316" },
                   { name: "Fuel Storage", val: "Stable", color: "#10b981" },
                   { name: "Urban Housing", val: "Low", color: "#6366f1" }
                 ].map(s => (
                   <div key={s.name} className="flex items-center justify-between p-2 rounded-lg bg-background/30 border border-border/50">
                      <div className="flex items-center gap-2">
                         <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: s.color }} />
                         <span className="text-[10px] font-bold text-text-secondary uppercase">{s.name}</span>
                      </div>
                      <span className="text-[10px] font-black text-text-primary uppercase tracking-tighter">{s.val}</span>
                   </div>
                 ))}
              </div>
           </div>
           <button onClick={() => setActiveModal('sectors')} className="mt-6 flex items-center justify-between text-[10px] font-black uppercase text-primary tracking-widest hover:translate-x-1 transition-transform">
              Explore Analysis <ChevronRight size={14} />
           </button>
        </div>

        <div className="colsi-card p-8 lg:col-span-1 bg-surface-elevated/50 flex flex-col items-center justify-center text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
               <Globe className="text-primary" size={20} />
            </div>
            <div>
               <h4 className="text-[10px] font-black text-text-primary uppercase tracking-[0.2em]">Regional Sync</h4>
               <p className="text-[9px] text-text-secondary uppercase mt-1">Cross-Sector Node Locking Active</p>
            </div>
        </div>
      </div>


      <div className="colsi-card p-10 !max-w-none bg-surface-elevated border-l-4 border-l-primary relative overflow-hidden group">
         <div className="absolute top-0 right-0 p-10 opacity-[0.03] group-hover:opacity-10 transition-opacity">
            <Cpu size={200} />
         </div>
         <div className="max-w-4xl relative z-10">
            <div className="flex items-center gap-4 mb-6">
               <div className="px-3 py-1 bg-primary/10 rounded-full flex items-center gap-2 border border-primary/20">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
                  <span className="text-[10px] font-black text-primary uppercase tracking-[0.2em] font-mono">Analytics Insight Briefing</span>
               </div>
            </div>
            <h3 className="text-2xl font-bold text-text-primary tracking-tight mb-4">Strategic Synthesis: Projected Cost Peaks</h3>
            <p className="text-text-secondary text-base leading-relaxed font-medium">
              The current <span className="text-text-primary font-bold">{overallIndex} Aggregate Score</span> is primarily driven by energy input variance impacting regional food distribution logistics. Analytics suggest a potential convergence in metropolitan housing costs.
            </p>
         </div>
      </div>

      <div className="colsi-card p-10 !max-w-none border-dashed border-2 border-border/50 bg-background/50">
         <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
               <Activity size={20} className="text-primary" />
               <h3 className="text-xs font-black uppercase tracking-[0.3em] text-text-primary">Synchronized Stream Monitor</h3>
            </div>
            <div className="flex items-center gap-2 px-3 py-1 bg-primary/10 rounded-full">
               <span className="text-[9px] font-black text-primary uppercase tracking-widest">End-to-End Latency: 42ms</span>
            </div>
         </div>
         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
               <div key={i} className="h-16 rounded-xl border border-border flex items-center justify-center relative group hover:border-primary/30 transition-all overflow-hidden">
                  <div className="absolute inset-0 bg-primary/5 -translate-x-full group-hover:translate-x-0 transition-transform duration-1000" />
                  <div className="text-center relative z-10">
                     <p className="text-[8px] font-black text-text-secondary uppercase">HUB_{i+101}</p>
                     <p className="text-[10px] font-bold text-text-primary">ACTIVE</p>
                  </div>
               </div>
            ))}
         </div>
      </div>

       </div>
 
       <div className="p-10 flex flex-col items-center justify-center gap-4">
         <div className="w-20 h-1 bg-gradient-to-r from-transparent via-primary/30 to-transparent" />
         <p className="text-[9px] text-text-secondary text-center uppercase tracking-[0.3em] opacity-40">
           Strategic Analytics Core Active // Secure Feed: COLSI_ENTERPRISE_CORE // {new Date().toISOString()}
         </p>
      </div>
    </div>
  );
};

export default Dashboard;
