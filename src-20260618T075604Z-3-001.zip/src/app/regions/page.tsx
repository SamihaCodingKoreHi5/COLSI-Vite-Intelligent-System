"use client";

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Search, 
  MapPin, 
  TrendingUp, 
  TrendingDown, 
  ChevronRight,
  Zap,
  ShoppingBasket,
  Car,
  Home,
  X
} from 'lucide-react';
import { getStressLevelColor } from '../../services/colsiCore';

import type { Region, SectorStatProps } from '../../types/economic';

const RegionsPage = () => {
  const [selectedRegion, setSelectedRegion] = useState<Region | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const regions: Region[] = [
    { 
      id: '1', 
      name: 'Dhaka Metropolitan', 
      score: 84.5, 
      trend: 'up', 
      status: 'CRITICAL',
      factors: { energy: 92, food: 88, transport: 74, housing: 82 } 
    },
    { 
      id: '2', 
      name: 'Chattogram Port', 
      score: 78.2, 
      trend: 'up', 
      status: 'HIGH',
      factors: { energy: 76, food: 82, transport: 88, housing: 65 } 
    },
    { 
      id: '3', 
      name: 'Sylhet Division', 
      score: 72.1, 
      trend: 'stable', 
      status: 'HIGH',
      factors: { energy: 68, food: 74, transport: 70, housing: 76 } 
    },
    { 
      id: '4', 
      name: 'Rajshahi North', 
      score: 45.4, 
      trend: 'down', 
      status: 'MODERATE',
      factors: { energy: 42, food: 48, transport: 50, housing: 41 } 
    },
    { 
      id: '5', 
      name: 'Khulna Industrial', 
      score: 74.8, 
      trend: 'up', 
      status: 'HIGH',
      factors: { energy: 80, food: 72, transport: 76, housing: 71 } 
    },
    { 
      id: '6', 
      name: 'Barishal Coastal', 
      score: 22.3, 
      trend: 'down', 
      status: 'STABLE',
      factors: { energy: 18, food: 24, transport: 20, housing: 27 } 
    }
  ];

  const filteredRegions = regions.filter(r => r.name.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <div className="space-y-10">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-text-primary uppercase tracking-tight">Regional Stress Vectors</h1>
          <p className="text-text-secondary mt-1">Localized affordability monitoring across critical municipal sectors.</p>
        </div>
        <div className="w-80 relative group">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-text-secondary w-4 h-4 group-focus-within:text-primary transition-colors" />
          <input 
            type="text" 
            placeholder="Search regional sectors..." 
            className="w-full bg-surface-elevated border border-border rounded-lg py-2 pl-10 pr-4 text-sm text-text-primary outline-none focus:border-primary/50 transition-all placeholder:text-text-secondary/50 uppercase tracking-widest text-[10px]"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <AnimatePresence mode='popLayout'>
          {filteredRegions.map((region, idx) => {
            const statusColor = getStressLevelColor(region.status);
            return (
              <motion.div 
                key={region.id}
                layout
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
                className="colsi-card group cursor-pointer border border-transparent hover:border-border hover:bg-surface-elevated transition-all p-8"
                onClick={() => setSelectedRegion(region)}
              >
                <div className="flex justify-between items-start mb-10">
                  <div 
                    className="p-3 rounded-lg border flex items-center justify-center transition-colors"
                    style={{ backgroundColor: `${statusColor}10`, borderColor: `${statusColor}30`, color: statusColor }}
                  >
                    <MapPin size={18} />
                  </div>
                  <div 
                    className="text-[10px] font-bold px-3 py-1 rounded-full border"
                    style={{ color: statusColor, borderColor: `${statusColor}40`, backgroundColor: `${statusColor}10` }}
                  >
                    {region.status} STRESS
                  </div>
                </div>

                <div className="mb-8">
                  <p className="text-[10px] font-bold text-text-secondary uppercase tracking-[0.2em]">COLSI Index</p>
                  <div className="flex items-baseline gap-2 mt-1">
                    <h2 className="text-5xl font-bold tracking-tighter text-text-primary">{region.score}</h2>
                    <span className="text-[10px] font-bold text-primary flex items-center gap-1">
                      {region.trend === 'up' ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
                      {region.trend.toUpperCase()}
                    </span>
                  </div>
                  <h4 className="text-lg font-bold text-text-primary mt-2">{region.name}</h4>
                </div>

                <div className="space-y-4 mb-6">
                  <FactorMiniRow label="Energy" value={region.factors.energy} color={getStressLevelColor(region.factors.energy > 80 ? 'CRITICAL' : region.factors.energy > 60 ? 'HIGH' : 'MODERATE')} />
                  <FactorMiniRow label="Food" value={region.factors.food} color={getStressLevelColor(region.factors.food > 80 ? 'CRITICAL' : region.factors.food > 60 ? 'HIGH' : 'MODERATE')} />
                </div>

                <div className="flex items-center gap-2 text-[10px] font-bold text-primary uppercase tracking-[0.2em] opacity-40 group-hover:opacity-100 transition-all">
                  Sector Breakdown <ChevronRight size={14} />
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      <AnimatePresence>
        {selectedRegion && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 backdrop-blur-md bg-black/60">
            <motion.div 
               initial={{ opacity: 0, y: 20 }}
               animate={{ opacity: 1, y: 0 }}
               exit={{ opacity: 0, y: 20 }}
               className="w-full max-w-xl bg-surface border border-border rounded-2xl overflow-hidden shadow-2xl"
            >
               <div className="flex items-center justify-between p-6 border-b border-border bg-surface-elevated/50">
                  <div className="flex items-center gap-3">
                     <MapPin size={20} className="text-primary" />
                     <h3 className="text-xl font-bold text-text-primary">{selectedRegion.name}</h3>
                  </div>
                  <button 
                    onClick={() => setSelectedRegion(null)}
                    className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-surface-elevated transition-colors text-text-secondary hover:text-text-primary border border-border"
                  >
                    <X size={18} />
                  </button>
               </div>

               <div className="p-8 space-y-8">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="colsi-card p-6 border-primary/20 bg-primary/5 text-center">
                       <p className="text-[10px] font-bold text-text-secondary uppercase mb-1">Aggregate Load</p>
                       <p className="text-3xl font-black text-text-primary">{selectedRegion.score}</p>
                    </div>
                    <div className="colsi-card p-6 text-center">
                       <p className="text-[10px] font-bold text-text-secondary uppercase mb-1">Stress Band</p>
                       <p className={`text-lg font-bold ${getStressLevelColor(selectedRegion.status)}`}>{selectedRegion.status}</p>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <p className="text-[11px] font-bold text-text-secondary uppercase tracking-widest text-center border-b border-border pb-4">Sector Intelligence Vectors</p>
                    <div className="grid grid-cols-2 gap-x-12 gap-y-6">
                       <SectorStat icon={<Zap size={16}/>} label="Energy" value={selectedRegion.factors.energy} />
                       <SectorStat icon={<ShoppingBasket size={16}/>} label="Food" value={selectedRegion.factors.food} />
                       <SectorStat icon={<Car size={16}/>} label="Transport" value={selectedRegion.factors.transport} />
                       <SectorStat icon={<Home size={16}/>} label="Housing" value={selectedRegion.factors.housing} />
                    </div>
                  </div>

                  <div className="p-4 bg-surface-elevated border border-border rounded-xl text-center">
                    <p className="text-[10px] text-text-secondary uppercase tracking-[0.2em]">
                      Status: Intelligence verified for {selectedRegion.name.toUpperCase()}
                    </p>
                  </div>
               </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

const FactorMiniRow = ({ label, value, color }: { label: string, value: number, color: string }) => (
  <div className="space-y-1.5">
    <div className="flex justify-between text-[9px] font-bold uppercase tracking-widest">
      <span className="text-text-secondary">{label}</span>
      <span style={{ color }}>{value}%</span>
    </div>
    <div className="h-1 w-full bg-border rounded-full overflow-hidden">
      <motion.div 
        initial={{ width: 0 }}
        animate={{ width: `${value}%` }}
        className="h-full"
        style={{ backgroundColor: color }}
      />
    </div>
  </div>
);



const SectorStat = ({ icon, label, value }: SectorStatProps) => (
  <div className="flex items-center gap-4">
    <div className="p-2.5 bg-surface-elevated border border-border rounded-xl text-text-secondary">
      {icon}
    </div>
    <div>
      <p className="text-[10px] font-bold text-text-secondary uppercase tracking-tighter">{label}</p>
      <div className="flex items-baseline gap-1.5">
        <span className="text-lg font-bold text-text-primary">{value}</span>
        <span className="text-[9px] font-medium text-text-secondary opacity-40">LF</span>
      </div>
    </div>
  </div>
);

export default RegionsPage;
