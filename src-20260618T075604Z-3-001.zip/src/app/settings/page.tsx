"use client";

import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import gsap from 'gsap';
import { 
  User, 
  Shield, 
  Monitor,
  CheckCircle2,
  ChevronRight,
  ShieldCheck,
  Zap,
  HardDrive
} from 'lucide-react';
import { usePlatform } from '../../hooks/usePlatform';

const SettingsPage = () => {
  const { addNotification } = usePlatform();
  const containerRef = useRef<HTMLDivElement>(null);
  
  const [settings, setSettings] = useState({
    pushNotifications: true,
    realTimeSync: true,
    advancedAnalytics: false,
    mfaEnabled: true,
    publicProfile: false
  });

  useEffect(() => {
    if (containerRef.current) {
      gsap.from(".settings-section", {
        opacity: 0,
        y: 20,
        stagger: 0.1,
        duration: 0.8,
        ease: "expo.out"
      });
    }
  }, []);

  const toggleSetting = (key: keyof typeof settings) => {
    setSettings(prev => ({ ...prev, [key]: !prev[key] }));
    addNotification(`Parameter ${key} updated.`, 'info');
  };

  const handleSave = () => {
    addNotification('Platform configuration synchronized with secure cloud.', 'success');
  };

  return (
    <div ref={containerRef} className="space-y-10">
      <header>
        <div className="flex items-center gap-2 text-primary mb-2">
           <Zap size={14} />
           <span className="text-[10px] font-bold uppercase tracking-[0.3em]">Platform Configuration Console</span>
        </div>
        <h1 className="text-text-primary">System Settings</h1>
        <p className="text-text-secondary mt-1">Manage operator credentials, intelligence synchronization, and tactical display preferences.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Profile Section */}
        <section className="settings-section colsi-card group flex flex-col gap-8 p-8">
          <div className="flex items-center justify-between border-b border-border pb-6">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center border border-primary/20">
                <User size={20} />
              </div>
              <div>
                <h3 className="text-lg font-bold text-text-primary">Operator Identity</h3>
                <span className="text-[10px] font-bold text-text-secondary uppercase tracking-widest">Auth Level: Level_4_Federal</span>
              </div>
            </div>
            <ShieldCheck size={18} className="text-text-secondary opacity-20 group-hover:opacity-100 group-hover:text-primary transition-all" />
          </div>
          <div className="space-y-6">
            <SettingToggle 
              label="Public Identifier" 
              desc="Display operator signature in regional intelligence reports" 
              active={settings.publicProfile} 
              onToggle={() => toggleSetting('publicProfile')} 
            />
            <SettingToggle 
              label="Multi-Factor Auth" 
              desc="Require biometric secondary verification for all transactions" 
              active={settings.mfaEnabled} 
              onToggle={() => toggleSetting('mfaEnabled')} 
            />
          </div>
        </section>

        {/* Platform Section */}
        <section className="settings-section colsi-card group flex flex-col gap-8 p-8">
          <div className="flex items-center justify-between border-b border-border pb-6">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-lg bg-surface-elevated border border-border flex items-center justify-center text-text-primary">
                <Monitor size={20} />
              </div>
              <div>
                <h3 className="text-lg font-bold text-text-primary">Display Architecture</h3>
                <span className="text-[10px] font-bold text-text-secondary uppercase tracking-widest">Interface Preferences</span>
              </div>
            </div>
            <ChevronRight size={16} className="text-text-secondary" />
          </div>
          <div className="space-y-6">
            <SettingToggle 
              label="Push Status Alerts" 
              desc="Haptic and desktop notifications for critical delta changes" 
              active={settings.pushNotifications} 
              onToggle={() => toggleSetting('pushNotifications')} 
            />
            <SettingToggle 
              label="Hyper-Sync Mode" 
              desc="Enable 2s ultra-low latency data refreshments" 
              active={settings.realTimeSync} 
              onToggle={() => toggleSetting('realTimeSync')} 
            />
          </div>
        </section>

        {/* Data Section */}
        <section className="settings-section colsi-card group flex flex-col gap-6 p-8">
          <div className="flex items-center gap-4 border-b border-border pb-6">
            <div className="w-10 h-10 rounded-lg bg-surface-elevated border border-border flex items-center justify-center text-text-primary">
              <HardDrive size={20} />
            </div>
            <div>
              <h3 className="text-lg font-bold text-text-primary">Strategic Assets</h3>
              <span className="text-[10px] font-bold text-text-secondary uppercase tracking-widest">Data Management</span>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <button 
              className="btn-primary flex items-center justify-center gap-2 text-[10px] py-4" 
              onClick={() => addNotification('Regenerating secure API keys...', 'info')}
            >
              Regenerate API Key
            </button>
            <button 
              className="btn-secondary flex items-center justify-center gap-2 text-[10px] py-4" 
              onClick={() => addNotification('Generating encrypted JSON export...', 'success')}
            >
              Export Intelligence
            </button>
          </div>
        </section>

        {/* Security Section */}
        <section className="settings-section colsi-card group flex flex-col gap-6 p-8 overflow-hidden relative">
          <div className="absolute top-0 right-0 p-6 opacity-5 group-hover:opacity-10 group-hover:scale-110 transition-all duration-700">
             <Shield size={100} strokeWidth={1} />
          </div>
          <div className="flex items-center gap-4 relative z-10">
            <div className="w-10 h-10 rounded-lg bg-surface-elevated border border-border flex items-center justify-center text-primary shadow-lg shadow-primary/10">
              <Shield size={20} />
            </div>
            <div>
              <h3 className="text-lg font-bold text-text-primary">Access Control</h3>
              <span className="text-[10px] font-bold text-text-secondary uppercase tracking-widest">Security Policy</span>
            </div>
          </div>
          <div className="relative z-10">
             <div className="p-6 rounded-xl bg-surface-elevated border-l-4 border-primary shadow-inner">
                <p className="text-text-secondary font-medium text-sm leading-relaxed">
                   Authorized as <strong className="text-text-primary">Senior Regional Director</strong>. 
                   Global override keys are locked under Tier-5 protocol bypass mechanisms.
                </p>
             </div>
          </div>
        </section>
      </div>

      <button 
        className="btn-primary w-full py-6 flex items-center justify-center gap-3 group !rounded-2xl" 
        onClick={handleSave}
      >
        <CheckCircle2 size={18} className="group-hover:scale-110 transition-transform" />
        <span className="text-sm font-bold uppercase tracking-widest">Finalize Platform State</span>
      </button>
    </div>
  );
};

const SettingToggle = ({ label, desc, active, onToggle }: { label: string, desc: string, active: boolean, onToggle: () => void }) => (
  <div className="flex justify-between items-center group/toggle">
    <div className="flex flex-col">
      <span className="text-sm font-bold text-text-primary tracking-tight transition-colors group-hover/toggle:text-primary">{label}</span>
      <span className="text-xs text-text-secondary mt-1">{desc}</span>
    </div>
    <button 
      className={`w-12 h-6 rounded-full transition-all duration-300 p-1 flex items-center ${active ? 'bg-primary' : 'bg-surface-elevated border border-border'}`}
      onClick={onToggle}
    >
      <motion.div 
        animate={{ x: active ? 24 : 0 }}
        transition={{ type: "spring", stiffness: 500, damping: 30 }}
        className={`w-4 h-4 rounded-full shadow-md ${active ? 'bg-white' : 'bg-text-secondary/50'}`}
      />
    </button>
  </div>
);

export default SettingsPage;
