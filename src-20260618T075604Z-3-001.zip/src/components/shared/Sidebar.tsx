import { NavLink } from 'react-router-dom';
import { LayoutDashboard, Map, BarChart3, LineChart, Bell, LogOut } from 'lucide-react';

const Sidebar = () => {
  const menuItems = [
    { to: "/", icon: <LayoutDashboard size={20} />, label: "Dashboard" },
    { to: "/analytics", icon: <BarChart3 size={20} />, label: "Analytics" },
    { to: "/regions", icon: <Map size={20} />, label: "Regions" },
    { to: "/insights", icon: <LineChart size={20} />, label: "Performance Trends" },
    { to: "/alerts", icon: <Bell size={20} />, label: "Alerts" },
  ];

  return (
    <div className="w-64 h-full flex flex-col bg-surface border-r border-border relative z-50">
      <div className="flex items-center gap-3 p-8">
        <div className="w-8 h-8 rounded-lg overflow-hidden border border-primary/20">
          <img src="/favicon.png" alt="COLSI" className="w-full h-full object-cover" />
        </div>
        <span className="text-xl font-bold tracking-tight text-text-primary">COLSI</span>
      </div>

      <nav className="flex-1 px-4 py-4 space-y-1">
        {menuItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) => 
              `flex items-center justify-between px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                isActive 
                  ? 'bg-primary/10 text-primary' 
                  : 'text-text-secondary hover:text-text-primary hover:bg-surface-elevated'
              }`
            }
          >
            {({ isActive }) => (
              <>
                <div className="flex items-center gap-3">
                  {item.icon}
                  <span>{item.label}</span>
                </div>
                {isActive && <div className="w-1 h-4 bg-primary rounded-full" />}
              </>
            )}
          </NavLink>
        ))}
      </nav>

      <div className="p-4 border-t border-border">
        <div className="p-3 flex items-center gap-3 rounded-xl bg-surface-elevated border border-border group cursor-pointer">
          <div className="w-9 h-9 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center text-primary text-xs font-bold uppercase">
            AD
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-text-primary truncate">Admin User</p>
            <p className="text-[11px] text-text-secondary truncate uppercase tracking-wider">Administrator Access</p>
          </div>
          <LogOut size={16} className="text-text-secondary group-hover:text-primary transition-colors" />
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
