import React, { createContext, useState, type ReactNode } from 'react';
import { CheckCircle2, AlertTriangle, Info } from 'lucide-react';

interface Notification {
  id: string;
  message: string;
  type: 'success' | 'warning' | 'info';
  timestamp: number;
}

interface PlatformContextType {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  notifications: Notification[];
  addNotification: (message: string, type?: 'success' | 'warning' | 'info') => void;
  clearNotifications: () => void;
}

export const PlatformContext = createContext<PlatformContextType | undefined>(undefined);

export const PlatformProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [notifications, setNotifications] = useState<Notification[]>([]);

  const addNotification = (message: string, type: 'success' | 'warning' | 'info' = 'info') => {
    const id = Math.random().toString(36).substr(2, 9);
    const newNotification: Notification = {
      id,
      message,
      type,
      timestamp: Date.now(),
    };
    setNotifications(prev => [newNotification, ...prev].slice(0, 5));
    
    // Auto-remove notification after 5 seconds
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 5000);
  };

  const clearNotifications = () => setNotifications([]);

  return (
    <PlatformContext.Provider value={{ 
      searchQuery, 
      setSearchQuery, 
      notifications, 
      addNotification, 
      clearNotifications 
    }}>
      {children}
      
      {/* Global Notification Toast Overlay */}
      <div className="notification-overlay">
        {notifications.map(n => (
          <div key={n.id} className={`notification-toast ${n.type} animate-notification`}>
            <div className="notification-indicator" />
            <div className="notification-icon">
              {n.type === 'success' && <CheckCircle2 size={18} />}
              {n.type === 'warning' && <AlertTriangle size={18} />}
              {n.type === 'info' && <Info size={18} />}
            </div>
            <div className="notification-content">{n.message}</div>
          </div>
        ))}
      </div>

      <style>{`
        .notification-overlay {
          position: fixed;
          top: 40px;
          right: 40px;
          z-index: 9999;
          display: flex;
          flex-direction: column;
          gap: 16px;
          pointer-events: none;
        }
        .notification-toast {
          background: white;
          padding: 24px 32px;
          min-width: 400px;
          display: flex;
          align-items: center;
          gap: 20px;
          pointer-events: auto;
          box-shadow: 0 30px 60px -12px rgba(0,0,0,0.15), 0 18px 36px -18px rgba(0,0,0,0.1);
          border-radius: 32px;
          border: 1px solid rgba(0,0,0,0.05);
          position: relative;
          overflow: hidden;
        }
        .notification-indicator {
          position: absolute;
          left: 0;
          top: 0;
          bottom: 0;
          width: 6px;
          background: black;
        }
        .notification-toast.success .notification-indicator { background: black; }
        .notification-toast.warning .notification-indicator { background: #000; }
        .notification-toast.info .notification-indicator { background: #000; }
        
        .notification-icon {
          display: flex;
          align-items: center;
          justify-content: center;
          color: black;
        }
        .notification-content {
          font-weight: 700;
          font-size: 14px;
          letter-spacing: -0.01em;
          color: black;
        }

        @keyframes notification-slide {
          0% { transform: translateX(100%) scale(0.9); opacity: 0; }
          100% { transform: translateX(0) scale(1); opacity: 1; }
        }
        
        .animate-notification {
          animation: notification-slide 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
      `}</style>
    </PlatformContext.Provider>
  );
};

// usePlatform hook moved to src/hooks/usePlatform.ts to resolve react-refresh/only-export-components warning
