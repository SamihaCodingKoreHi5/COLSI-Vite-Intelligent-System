export interface RawDataPoint {
  value: number;
  source: string;
  timestamp: number;
  location?: string;
  metadata?: Record<string, unknown>;
}

/**
 * FOOD INGESTOR
 * Sources: E-commerce scrapers, online grocery price pulls, market APIs, crowd inputs.
 * Frequency: Daily (early morning)
 */
export const fetchFoodData = async (): Promise<RawDataPoint[]> => {
  // Simulation of scraping logic
  return [
    { value: 65.5, source: 'GroceryAPI', timestamp: Date.now(), location: 'Dhaka' },
    { value: 68.2, source: 'MarketScraper', timestamp: Date.now(), location: 'Chattogram' },
    { value: 72.0, source: 'UserReport', timestamp: Date.now(), location: 'Sylhet' }
  ];
};

/**
 * ENERGY INGESTOR
 * Sources: Government board APIs, utility pricing, crowd-sourced outage reports.
 * Frequency: Hourly/Daily
 */
export const fetchEnergyData = async (): Promise<RawDataPoint[]> => {
  return [
    { value: 10.2, source: 'NationalBoard', timestamp: Date.now(), metadata: { type: 'Electricity Tariff' } },
    { value: 12.5, source: 'LNG_Import_Stream', timestamp: Date.now(), metadata: { type: 'LNG Price' } },
    { value: 120, source: 'UserReport', timestamp: Date.now(), metadata: { type: 'LoadShedding_Minutes' } }
  ];
};

/**
 * TRANSPORT INGESTOR
 * Sources: Fuel price APIs, Ride-sharing sampling, Public transport data.
 * Frequency: Daily (Fuel) / Sampled (Fares)
 */
export const fetchTransportData = async (): Promise<RawDataPoint[]> => {
  return [
    { value: 108.0, source: 'FuelBoard', timestamp: Date.now(), metadata: { type: 'Diesel' } },
    { value: 125.0, source: 'OctaneAPI', timestamp: Date.now(), metadata: { type: 'Octane' } },
    { value: 450.0, source: 'RideShareSampling', timestamp: Date.now(), location: 'Dhaka_Inter_District' }
  ];
};

/**
 * HOUSING INGESTOR
 * Sources: Real estate platforms, Rent listing scrapers, User rent reports.
 * Frequency: Daily scraping, Weekly smoothing.
 */
export const fetchHousingData = async (): Promise<RawDataPoint[]> => {
  return [
    { value: 25000, source: 'RealEstatePortal', timestamp: Date.now(), location: 'Gulshan' },
    { value: 18000, source: 'ListingScraper', timestamp: Date.now(), location: 'Mirpur' },
    { value: 15000, source: 'UserReport', timestamp: Date.now(), location: 'Uttara' }
  ];
};
