import * as ingestor from './ingestion/dataIngestor';
import * as scoring from './scoringEngine';
import * as ml from './mlPredictor';

/**
 * COLSI STRATEGIC COORDINATOR
 * Orchestrates the full 24-hour data analytics lifecycle.
 */
export const runStrategicAnalyticsPipeline = async () => {
  console.log("⚡ Starting COLSI 24-Hour Strategic Analytics Pipeline...");

  // 1. DATA COLLECTION (Ingestion Layer)
  const rawFood = await ingestor.fetchFoodData();
  const rawEnergy = await ingestor.fetchEnergyData();
  const rawTransport = await ingestor.fetchTransportData();
  const rawHousing = await ingestor.fetchHousingData();

  // 2. SCORING & NORMALIZATION (Analytics Layer)
  // Baselines represent the historical truth
  const baselines = { food: 60.0, energy: 10.0, transport: 100.0, housing: 18000 };

  const foodScore = scoring.processFactor(rawFood, baselines.food);
  const energyScore = scoring.processFactor(rawEnergy, baselines.energy);
  const transportScore = scoring.processFactor(rawTransport, baselines.transport);
  const housingScore = scoring.processFactor(rawHousing, baselines.housing);

  // 3. MASTER COLSI COMBINATION
  const currentCOLSI = scoring.computeCOLSI(
    foodScore.score,
    housingScore.score,
    transportScore.score,
    energyScore.score
  );

  // 4. PERFORMANCE FORECASTING
  // Extracting features from a simulated 7-day history
  const simulatedHistory = [68, 69, 70, 71, 71.5, 72, currentCOLSI];
  const features = ml.extractFeatures(simulatedHistory, 45); // 45 = Moderate User Sentiment

  const prediction1d = ml.forecastMarketPressure(features, '1d');
  const prediction7d = ml.forecastMarketPressure(features, '7d');

  // 5. ANOMALY DETECTION
  const isAnomaly = ml.detectAnomaly(currentCOLSI, prediction1d);

  return {
    status: "SUCCESS",
    timestamp: Date.now(),
    current: {
      score: currentCOLSI,
      factors: { foodScore, energyScore, transportScore, housingScore }
    },
    forecast: {
      t_plus_1d: prediction1d,
      t_plus_7d: prediction7d,
      anomalyDetected: isAnomaly
    },
    meta: {
      logic: "ANALYTICS_V2_INTEGRATED",
      engine: "COLSI_STRATEGIC_CORE"
    }
  };
};
