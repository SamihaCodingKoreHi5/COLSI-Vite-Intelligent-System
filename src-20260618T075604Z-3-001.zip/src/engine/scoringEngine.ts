import type { RawDataPoint } from './ingestion/dataIngestor';

export interface FactorScore {
  score: number;
  baseline: number;
  delta: number;
  timestamp: number;
}

/**
 * CLEAN & NORMALIZE
 *Standardizes prices, removes outliers, and handles missing values.
 */
const normalize = (val: number, baseline: number): number => {
  if (baseline === 0) return 0;
  const change = (val - baseline) / baseline;
  // Simple normalization to 0-100 scale (where 50 is baseline)
  return Math.min(100, Math.max(0, 50 + (change * 100)));
};

/**
 * SCORING ENGINE
 * Corresponds to "Step 2 & 3" of the 24-hour pipeline.
 */
export const processFactor = (raw: RawDataPoint[], baseline: number): FactorScore => {
  const values = raw.map(p => p.value);
  if (values.length === 0) return { score: 0, baseline, delta: 0, timestamp: Date.now() };

  // Remove outliers (e.g. values > 3 standard deviations from mean)
  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  const filtered = values.filter(v => Math.abs(v - mean) < (mean * 2)); // Simplified outlier rejection

  const average = filtered.length > 0 ? filtered.reduce((a, b) => a + b, 0) / filtered.length : mean;
  const delta = average - baseline;
  const score = normalize(average, baseline);

  return {
    score: parseFloat(score.toFixed(2)),
    baseline,
    delta: parseFloat(delta.toFixed(2)),
    timestamp: Date.now()
  };
};

/**
 * COLSI COMBINER
 * Final aggregate score using weighted factor values.
 */
export const computeCOLSI = (
  food: number, 
  housing: number, 
  transport: number, 
  energy: number
): number => {
  const result = (0.30 * food) + (0.25 * housing) + (0.20 * transport) + (0.25 * energy);
  return parseFloat(result.toFixed(2));
};
