import { runStrategicAnalyticsPipeline as runIntelligencePipeline } from './intelligenceSystem';

async function verifyEngine() {
  console.log("=== COLSI ENGINE VERIFICATION START ===");
  try {
    const result = await runIntelligencePipeline();
    console.log("Pipeline Execution Result:");
    console.log(JSON.stringify(result, null, 2));
    
    if (result.status === "SUCCESS" && result.forecast.t_plus_1d > 0) {
      console.log("✅ Verification Successful: Ingestion, Scoring, and Prediction operational.");
    } else {
      console.log("❌ Verification Failed: Unexpected pipeline output.");
    }
  } catch (error) {
    console.error("❌ Verification Failed: Execution error.", error);
  }
  console.log("=== COLSI ENGINE VERIFICATION END ===");
}

verifyEngine();
