import { useContext } from 'react';
import { PlatformContext } from '../context/PlatformContext';

export const usePlatform = () => {
  const context = useContext(PlatformContext);
  if (context === undefined) {
    throw new Error('usePlatform must be used within a PlatformProvider');
  }
  return context;
};
