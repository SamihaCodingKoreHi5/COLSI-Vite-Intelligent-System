import type { EconomicData, Insight } from '../types/economic';

export const generateInsights = (dataHistory: EconomicData[]): Insight[] => {
  if (dataHistory.length === 0) return [];
  
  const current = dataHistory[dataHistory.length - 1];
  const previous = dataHistory.length > 1 ? dataHistory[dataHistory.length - 2] : current;
  const insights: Insight[] = [];
  
  // 1. Inflation vs Income detection (Simulated)
  // Since we only have cost data, we'll simulate income as a stagnant factor
  const incomeTrend = 50; // Stagnant income level
  const avgCost = (current.energy + current.food + current.transport + current.housing) / 4;
  
  if (avgCost > incomeTrend * 1.2) {
    insights.push({
      id: `insight-${Date.now()}-1`,
      timestamp: Date.now(),
      title: 'Economic Stress Threshold Breached',
      description: 'The average cost of living has exceeded projected income levels by 20%. Stress levels are approaching critical in several urban sectors.',
      severity: 'critical',
      category: 'general',
    });
  }
  
  // 2. Energy Peak Anomalies
  if (current.energy > 80) {
    insights.push({
      id: `insight-${Date.now()}-2`,
      timestamp: Date.now(),
      title: 'Energy Demand Spike Detected',
      description: 'Rapid energy price inflation detected. Recommending immediate load-shedding measures or shifting non-essential usage to off-peak hours (1 AM - 5 AM).',
      severity: 'warning',
      category: 'energy',
    });
  }
  
  // 3. Food Trend Analysis
  const foodChange = current.food - previous.food;
  if (foodChange > 2) {
    insights.push({
      id: `insight-${Date.now()}-3`,
      timestamp: Date.now(),
      title: 'Food Supply Chain Instability',
      description: 'Significant day-over-day price increase in basic food commodities. Monitoring for hoarding or supply disruption in regional hubs.',
      severity: 'warning',
      category: 'food',
    });
  }
  
  // 4. Energy Savings Recommendation
  const bestHour = 3; // Simulated best hour for energy
  insights.push({
    id: `insight-${Date.now()}-4`,
    timestamp: Date.now(),
    title: 'Optimized Energy Usage Plan',
    description: `AI predicts energy costs will be lowest at ${bestHour}:00 AM tonight. Shifting energy-intensive operations could save up to 22% on daily utility costs.`,
    severity: 'info',
    category: 'energy',
  });

  return insights;
};
