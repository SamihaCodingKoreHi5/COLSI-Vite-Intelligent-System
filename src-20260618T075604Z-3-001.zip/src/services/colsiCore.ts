import type { COLSIResult } from '../types/economic';
import type { EconomicData } from '../types/economic';

const WEIGHTS = {
  energy: 0.4,
  food: 0.3,
  transport: 0.2,
  housing: 0.1,
};

export const calculateCOLSI = (data: EconomicData): COLSIResult => {
  const rawScore = 
    data.energy * WEIGHTS.energy +
    data.food * WEIGHTS.food +
    data.transport * WEIGHTS.transport +
    data.housing * WEIGHTS.housing;
    
  const score = Math.min(100, Math.max(1, rawScore));
    
  let level: COLSIResult['level'] = 'STABLE';
  if (score > 80) {
    level = 'CRITICAL';
  } else if (score > 60) {
    level = 'HIGH';
  } else if (score > 30) {
    level = 'MODERATE';
  }
  
  return {
    score: parseFloat(score.toFixed(2)),
    breakdown: {
      energyWeight: WEIGHTS.energy,
      foodWeight: WEIGHTS.food,
      transportWeight: WEIGHTS.transport,
      housingWeight: WEIGHTS.housing,
    },
    level,
  };
};

export const getStressLevelColor = (level: string): string => {
  switch (level) {
    case 'CRITICAL': return '#ef4444'; // red-500
    case 'HIGH': return '#f97316';     // orange-500
    case 'MODERATE': return '#eab308'; // yellow-500
    case 'STABLE': return '#22c55e';   // green-500
    default: return '#94a3b8';         // slate-400
  }
};
