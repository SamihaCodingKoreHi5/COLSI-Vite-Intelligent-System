import type { EconomicData } from '../types/economic';

export const simulateEnergy = (hour: number): number => {
  // Base consumption curve (sinusoidal)
  // Low at 3 AM (hour 3), High at 3 PM (hour 15)
  const base = 50 + 20 * Math.sin(((hour - 9) * Math.PI) / 12);
  
  // Evening peak boost (6 PM - 10 PM)
  let peak = 0;
  if (hour >= 18 && hour <= 22) {
    peak = 25;
  }
  
  // Morning peak boost (7 AM - 9 AM)
  let morningPeak = 0;
  if (hour >= 7 && hour <= 9) {
    morningPeak = 10;
  }
  
  const noise = (Math.random() - 0.5) * 5;
  
  return Math.min(100, Math.max(0, base + peak + morningPeak + noise));
};

export const simulateFood = (timestamp: number): number => {
  // Slow inflation trend (0.01% increase per hour)
  const hoursSinceStart = (timestamp - new Date('2026-01-01').getTime()) / (1000 * 60 * 60);
  const trend = 50 + 0.01 * hoursSinceStart;
  
  // Small daily fluctuation
  const dailyFluct = 2 * Math.sin(((hoursSinceStart % 24) * Math.PI) / 12);
  
  // Random price shocks (2% chance per hour)
  const shock = Math.random() < 0.02 ? Math.random() * 8 : 0;
  
  const noise = (Math.random() - 0.5) * 1;
  
  return Math.min(100, Math.max(0, trend + dailyFluct + shock + noise));
};

export const simulateTransport = (hour: number): number => {
  // Base transport cost
  const base = 30;
  
  // Rush hour spikes
  let spike = 0;
  if (hour >= 8 && hour <= 10) {
    spike = 35; // Morning rush
  } else if (hour >= 17 && hour <= 20) {
    spike = 40; // Evening rush
  }
  
  const noise = (Math.random() - 0.5) * 3;
  
  return Math.min(100, Math.max(0, base + spike + noise));
};

export const simulateHousing = (timestamp: number): number => {
  // Very stable, slow upward drift
  const hoursSinceStart = (timestamp - new Date('2026-01-01').getTime()) / (1000 * 60 * 60);
  const base = 60 + 0.002 * hoursSinceStart;
  
  const noise = (Math.random() - 0.5) * 0.5;
  
  return Math.min(100, Math.max(0, base + noise));
};

export const generateHistory = (hours: number = 24): EconomicData[] => {
  const data: EconomicData[] = [];
  const now = Date.now();
  
  for (let i = hours; i >= 0; i--) {
    const ts = now - i * 60 * 60 * 1000;
    const date = new Date(ts);
    const hour = date.getHours();
    
    data.push({
      timestamp: ts,
      energy: simulateEnergy(hour),
      food: simulateFood(ts),
      transport: simulateTransport(hour),
      housing: simulateHousing(ts),
    });
  }
  
  return data;
};
