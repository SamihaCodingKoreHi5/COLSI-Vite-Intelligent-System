export interface EconomicData {
  timestamp: number;
  energy: number;
  food: number;
  transport: number;
  housing: number;
}

export interface COLSIResult {
  score: number;
  breakdown: {
    energyWeight: number;
    foodWeight: number;
    transportWeight: number;
    housingWeight: number;
  };
  level: 'STABLE' | 'MODERATE' | 'HIGH' | 'CRITICAL';
}

export interface Insight {
  id: string;
  timestamp: string | number;
  title: string;
  description: string;
  severity: 'info' | 'warning' | 'critical' | 'Optimal' | 'Delta' | 'Notice';
  category: 'energy' | 'food' | 'transport' | 'housing' | 'general' | 'Market' | 'Policy' | 'Logistics';
  delta?: string;
}

export interface Alert {
  id: string;
  timestamp: string | number;
  region: string;
  type?: string;
  status: 'Critical' | 'Warning' | 'Stable' | 'low' | 'medium' | 'high';
  message: string;
}

export interface Region {
  id: string | number;
  name: string;
  score: number;
  currentScore?: number; // Aliasing for transition
  trend: string;
  status: string;
  factors?: {
    energy: number;
    food: number;
    transport: number;
    housing: number;
  };
}

export interface RegionData extends Region {
  indicators: {
    inflation: number;
    income_level: number;
    cost_of_living_index: number;
  };
}

export interface SectorStatProps {
  icon?: React.ReactNode;
  label: string;
  value: string | number;
  trend?: 'up' | 'down' | 'stable';
}

export interface PlatformContextType {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  notifications: Array<{id: string, message: string, type: 'info' | 'success' | 'warning' | 'error'}>;
  addNotification: (message: string, type: 'info' | 'success' | 'warning' | 'error') => void;
  clearNotifications: () => void;
}
