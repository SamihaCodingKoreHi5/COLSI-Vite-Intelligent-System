import { useState } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import Sidebar from '../../components/shared/Sidebar';
import Dashboard from '../../app/page';
import RegionsPage from '../../app/regions/page';
import AnalyticsPage from '../../app/analytics/page';
import InsightsPage from '../../app/insights/page';
import AlertsPage from '../../app/alerts/page';
import { usePlatform } from '../../hooks/usePlatform';
import { Search } from 'lucide-react';

export const StandardHub = () => {
  const { searchQuery, setSearchQuery } = usePlatform();
  const location = useLocation();
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  return (
    <div className="flex h-screen w-screen bg-background overflow-hidden selection:bg-primary/30">
      <Sidebar aria-label="Main Navigation" />
      
      <main className="flex-1 flex flex-col overflow-hidden relative">
        {/* Professional Top Bar */}
        <header className="h-16 border-b border-border bg-surface/50 backdrop-blur-md px-8 flex items-center justify-between z-40">
          <div className="flex-1 max-w-xl">
            <div className="relative group">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-text-secondary w-4 h-4 group-focus-within:text-primary transition-colors" />
              <input 
                type="text" 
                placeholder="Search COLSI factors or regional sectors..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-surface-elevated border border-border rounded-lg py-2 pl-10 pr-4 text-sm text-text-primary outline-none focus:border-primary/50 transition-all placeholder:text-text-secondary/50 uppercase tracking-widest text-[10px]"
              />
            </div>
          </div>

          <div className="flex items-center gap-6 text-text-secondary">
             <div className="flex items-center gap-4">
                <div className="flex items-center gap-2 px-3 py-1 bg-surface-elevated rounded-lg border border-border">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
                  <span className="text-[9px] font-bold text-text-primary uppercase tracking-widest">Active Data Stream</span>
                </div>
             </div>
             
             <div className="relative">
                <button 
                  onClick={() => setIsProfileOpen(!isProfileOpen)}
                  className="w-8 h-8 rounded-full bg-surface-elevated border border-border overflow-hidden p-0.5 hover:border-primary transition-colors"
                >
                    <div className="w-full h-full rounded-full bg-primary/20 flex items-center justify-center text-primary text-[10px] font-bold uppercase">AD</div>
                </button>

                <AnimatePresence>
                  {isProfileOpen && (
                    <>
                      <div className="fixed inset-0 z-40" onClick={() => setIsProfileOpen(false)} />
                      <motion.div 
                        initial={{ opacity: 0, y: 10, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 10, scale: 0.95 }}
                        className="absolute right-0 mt-2 w-64 bg-surface-elevated border border-border rounded-2xl shadow-2xl p-4 z-50"
                      >
                        <div className="flex items-center gap-3 mb-4 pb-4 border-b border-border">
                          <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary text-xs font-bold">AD</div>
                          <div>
                            <p className="text-xs font-bold text-text-primary">Admin User</p>
                            <p className="text-[10px] text-text-secondary">admin@colsi.int</p>
                          </div>
                        </div>
                        <div className="space-y-1">
                           <button className="w-full text-left px-3 py-2 rounded-lg text-[10px] font-bold uppercase tracking-widest text-text-secondary hover:bg-surface hover:text-primary transition-all">Profile Settings</button>
                           <button className="w-full text-left px-3 py-2 rounded-lg text-[10px] font-bold uppercase tracking-widest text-text-secondary hover:bg-surface hover:text-primary transition-all">Security Logs</button>
                           <div className="my-2 border-t border-border" />
                           <button className="w-full text-left px-3 py-2 rounded-lg text-[10px] font-bold uppercase tracking-widest text-error hover:bg-error/10 transition-all">Terminate Session</button>
                        </div>
                      </motion.div>
                    </>
                  )}
                </AnimatePresence>
             </div>
          </div>
        </header>
        
        <div className="flex-1 overflow-y-auto custom-scrollbar p-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="w-full"
            >
              <Routes location={location}>
                <Route path="/" element={<Dashboard />} />
                <Route path="/analytics" element={<AnalyticsPage />} />
                <Route path="/regions" element={<RegionsPage />} />
                <Route path="/insights" element={<InsightsPage />} />
                <Route path="/alerts" element={<AlertsPage />} />
              </Routes>
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}

export default StandardHub;
