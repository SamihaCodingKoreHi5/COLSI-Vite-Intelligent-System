import { Routes, Route, NavLink, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  LayoutDashboard, 
  Map as MapIcon, 
  LineChart, 
  BellRing, 
  Settings2,
  Search,
  Command,
  Activity,
  Cpu,
  LogOut
} from 'lucide-react';
import Dashboard from '../../app/page';
import RegionsPage from '../../app/regions/page';
import InsightsPage from '../../app/insights/page';
import AlertsPage from '../../app/alerts/page';
import SettingsPage from '../../app/settings/page';
import { usePlatform } from '../../hooks/usePlatform';

export const UltraHub = () => {
  const { searchQuery, setSearchQuery } = usePlatform();
  const location = useLocation();
  const navigate = useNavigate();

  return (
    <div className="relative flex h-screen w-screen bg-background text-on-surface overflow-hidden font-body [perspective:2000px] [transform-style:preserve-3d]">
      {/* Dynamic Background */}
      <div className="absolute inset-0 pointer-events-none opacity-40 [transform:translateZ(-150px)]">
        <div className="absolute top-[-20%] left-[-20%] w-[60%] h-[60%] bg-primary/10 rounded-full blur-[160px] animate-pulse"></div>
        <div className="absolute bottom-[-20%] right-[-20%] w-[50%] h-[50%] bg-accent/10 rounded-full blur-[140px]"></div>
        <div className="absolute inset-0 noise" />
      </div>

      {/* Strategic Sidebar */}
      <motion.aside 
        className="relative z-20 flex flex-col w-[320px] bg-background border-r border-white/5 px-6 py-10 group/sidebar [transform-style:preserve-3d]"
        style={{ transform: 'var(--z-raised)' }}
      >
        <header className="flex items-center gap-4 mb-14 px-4 preserve-3d cursor-pointer" onClick={() => navigate('/')}>
          <div className="w-12 h-12 bg-accent flex items-center justify-center rounded-2xl shadow-[0_0_30px_rgba(var(--accent-raw),0.4)] relative overflow-hidden preserve-3d">
            <div className="v-gloss opacity-20" />
            <Cpu size={22} className="text-white relative z-10" />
          </div>
          <div className="flex flex-col preserve-3d">
            <span className="text-xl font-black tracking-tighter text-white uppercase">COLSI <span className="text-accent">ULTRA</span></span>
            <span className="text-[9px] font-bold text-on-surface-variant uppercase tracking-[0.4em]">Hub_Alpha_88</span>
          </div>
        </header>

        <nav className="flex flex-col gap-2 flex-grow overflow-y-auto pr-1 custom-scrollbar preserve-3d">
          <UltraNavItem to="/" icon={<LayoutDashboard size={18} />} label="Global Monitoring" />
          <UltraNavItem to="/regions" icon={<MapIcon size={18} />} label="Regional Overview" />
          <UltraNavItem to="/insights" icon={<LineChart size={18} />} label="Performance Trends" />
          <UltraNavItem to="/alerts" icon={<BellRing size={18} />} label="System Alerts" />
          <UltraNavItem to="/settings" icon={<Settings2 size={18} />} label="System Settings" />
        </nav>

        <div className="mt-auto pt-6 border-t border-white/5 preserve-3d">
           <div className="v-glass p-5 rounded-[1.5rem] border-white/5 flex items-center gap-4 preserve-3d">
              <div className="w-10 h-10 rounded-xl bg-accent/20 border border-accent/20 overflow-hidden relative">
                 <img src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=100&h=100&auto=format&fit=crop" alt="User Profile" className="w-full h-full object-cover grayscale brightness-110" />
              </div>
              <div className="flex-grow">
                 <div className="text-[12px] font-black text-white">IMAM UD DOULA</div>
                 <div className="text-[9px] font-bold text-accent uppercase tracking-widest flex items-center gap-1.5 pt-0.5">
                    <span className="w-1 h-1 bg-accent rounded-full animate-pulse" />
                    Secure Session
                 </div>
              </div>
              <LogOut size={16} className="text-on-surface-variant hover:text-error transition-colors cursor-pointer" />
           </div>
        </div>
      </motion.aside>

      {/* Main Viewport */}
      <main className="relative z-10 flex-1 flex flex-col overflow-hidden [transform-style:preserve-3d]">
        {/* Navigation Bar */}
        <header className="sticky top-0 z-30 flex h-20 w-full items-center justify-between border-b border-white/5 bg-background/50 px-10 backdrop-blur-3xl shrink-0 preserve-3d">
          <div className="flex flex-1 items-center space-x-6">
            <div className="relative w-full max-w-xl group preserve-3d">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant w-4 h-4 group-focus-within:text-accent transition-colors" />
              <input 
                type="text" 
                placeholder="Search analytics..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="h-11 w-full rounded-xl bg-white/5 border border-white/5 pl-12 pr-4 text-[11px] font-bold tracking-widest text-on-surface outline-none transition-all focus:bg-white/10 focus:border-accent/40 placeholder:text-on-surface-variant/40"
              />
              <div className="absolute right-4 top-1/2 -translate-y-1/2 flex items-center gap-1 opacity-20 hidden md:flex">
                 <Command size={12} /> <span className="text-[10px] font-bold">K</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-8 preserve-3d">
            <div className="flex items-center gap-8 translate-z-raised">
              <div className="flex flex-col items-end">
                 <div className="text-[9px] font-black text-on-surface-variant uppercase tracking-widest mb-1 flex items-center gap-2">
                    <Activity size={10} className="text-accent animate-pulse" />
                    Live Monitoring
                 </div>
                 <div className="text-[14px] font-mono text-white tracking-tighter">TPS: 1,442.08</div>
              </div>
              <div className="w-px h-8 bg-white/5" />
              <div className="flex items-center gap-5">
                <motion.div whileHover={{ scale: 1.1 }} className="w-10 h-10 rounded-xl v-glass flex items-center justify-center text-on-surface-variant hover:text-white cursor-pointer transition-colors relative overflow-hidden">
                   <div className="v-gloss opacity-10" />
                   <BellRing size={18} />
                   <div className="absolute top-2 right-2 w-1.5 h-1.5 bg-accent rounded-full border border-background shadow-[0_0_8px_theme('colors.accent')]" />
                </motion.div>
                <div className="text-[10px] font-black underline underline-offset-4 decoration-accent/40 text-accent uppercase tracking-widest cursor-pointer hover:text-white transition-colors">Security_Level_1</div>
              </div>
            </div>
          </div>
        </header>

        {/* Analytics Dashboard */}
        <div className="flex-1 overflow-y-auto flex flex-col custom-scrollbar preserve-3d">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, scale: 0.96, transform: 'translateZ(-100px)' }}
              animate={{ opacity: 1, scale: 1, transform: 'translateZ(0px)' }}
              exit={{ opacity: 0, scale: 1.04, transform: 'translateZ(100px)' }}
              transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
              className="p-12 max-w-[1700px] mx-auto w-full preserve-3d flex-grow"
            >
              <Routes location={location}>
                <Route path="/" element={<Dashboard />} />
                <Route path="/regions" element={<RegionsPage />} />
                <Route path="/insights" element={<InsightsPage />} />
                <Route path="/alerts" element={<AlertsPage />} />
                <Route path="/settings" element={<SettingsPage />} />
              </Routes>
            </motion.div>
          </AnimatePresence>
          
          <footer className="mt-8 px-12 py-8 border-t border-white/5 flex items-center justify-between opacity-30 text-[9px] font-black uppercase tracking-[0.4em] pointer-events-none">
             <div>COLSI-ULTRA-REV-02</div>
             <div>DATA_SYNCHRONIZATION_ACTIVE</div>
             <div>System_Kernel: 4.1.9</div>
          </footer>
        </div>
      </main>
    </div>
  );
};

interface UltraNavItemProps {
  to: string;
  icon: React.ReactNode;
  label: string;
}

const UltraNavItem = ({ to, icon, label }: UltraNavItemProps) => (
  <NavLink 
    to={to} 
    className={({ isActive }) => `flex items-center gap-5 px-6 py-4 rounded-xl transition-all duration-500 relative group overflow-hidden preserve-3d ${isActive ? 'bg-accent/10 border border-accent/20 text-white shadow-[0_0_30px_rgba(var(--accent-raw),0.1)]' : 'text-on-surface-variant hover:text-white hover:bg-white/5 border border-transparent'}`}
    style={({ isActive }) => ({ transform: isActive ? 'var(--z-raised)' : 'var(--z-base)' })}
  >
    {({ isActive }) => (
      <>
        {isActive && (
          <motion.div 
            layoutId="ultra-active-glow"
            className="v-spectral absolute inset-0 opacity-40 z-0"
          />
        )}
        <div className={`relative z-10 transition-all duration-500 shrink-0 ${isActive ? 'scale-110 text-accent' : 'group-hover:text-white'}`}>
          {icon}
        </div>
        <motion.span className="relative z-10 text-[11px] font-black uppercase tracking-[0.2em] whitespace-nowrap transition-colors">
          {label}
        </motion.span>
        {isActive && (
          <motion.div 
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            className="relative z-10 ml-auto"
          >
            <div className="w-1 h-1 bg-accent rounded-full shadow-[0_0_10px_theme('colors.accent')]" />
          </motion.div>
        )}
      </>
    )}
  </NavLink>
);

export default UltraHub;
